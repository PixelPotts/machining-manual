import { HeightfieldRenderer } from './render/canvas.js';
import { SAFE_SAMPLE, CRASH_SAMPLE } from './samples.js';

const els = {
  status: document.querySelector('#status'),
  gcode: document.querySelector('#gcode'),
  report: document.querySelector('#report'),
  run: document.querySelector('#run'),
  sampleSafe: document.querySelector('#sampleSafe'),
  sampleCrash: document.querySelector('#sampleCrash'),
  view: document.querySelector('#view'),
  stockMinX: document.querySelector('#stockMinX'),
  stockMaxX: document.querySelector('#stockMaxX'),
  stockMinY: document.querySelector('#stockMinY'),
  stockMaxY: document.querySelector('#stockMaxY'),
  stockTopZ: document.querySelector('#stockTopZ'),
  stockBottomZ: document.querySelector('#stockBottomZ'),
  stockCell: document.querySelector('#stockCell'),
  toolDiameter: document.querySelector('#toolDiameter'),
  toolFlute: document.querySelector('#toolFlute'),
  toolShankDiameter: document.querySelector('#toolShankDiameter'),
  toolShankLength: document.querySelector('#toolShankLength'),
  holderDiameter: document.querySelector('#holderDiameter'),
  holderLength: document.querySelector('#holderLength'),
  fixtureMinX: document.querySelector('#fixtureMinX'),
  fixtureMaxX: document.querySelector('#fixtureMaxX'),
  fixtureMinY: document.querySelector('#fixtureMinY'),
  fixtureMaxY: document.querySelector('#fixtureMaxY'),
  fixtureMinZ: document.querySelector('#fixtureMinZ'),
  fixtureMaxZ: document.querySelector('#fixtureMaxZ')
};

const renderer = new HeightfieldRenderer(els.view);
const worker = new Worker('./src/verifier.worker.js', { type: 'module' });
let nextJobId = 1;

function numberFrom(id) {
  const value = Number(els[id].value);
  if (!Number.isFinite(value)) throw new Error(`${id} must be a number.`);
  return value;
}

function buildPayload() {
  return {
    gcode: els.gcode.value,
    stockParams: {
      minX: numberFrom('stockMinX'),
      maxX: numberFrom('stockMaxX'),
      minY: numberFrom('stockMinY'),
      maxY: numberFrom('stockMaxY'),
      topZ: numberFrom('stockTopZ'),
      bottomZ: numberFrom('stockBottomZ'),
      cell: numberFrom('stockCell')
    },
    toolParams: {
      diameter: numberFrom('toolDiameter'),
      fluteLength: numberFrom('toolFlute'),
      shankDiameter: numberFrom('toolShankDiameter'),
      shankLength: numberFrom('toolShankLength'),
      holderDiameter: numberFrom('holderDiameter'),
      holderLength: numberFrom('holderLength')
    },
    fixtureParams: {
      minX: numberFrom('fixtureMinX'),
      maxX: numberFrom('fixtureMaxX'),
      minY: numberFrom('fixtureMinY'),
      maxY: numberFrom('fixtureMaxY'),
      minZ: numberFrom('fixtureMinZ'),
      maxZ: numberFrom('fixtureMaxZ'),
      label: 'fixture box'
    },
    machineBounds: {
      minX: -20,
      maxX: 20,
      minY: -20,
      maxY: 20,
      minZ: -10,
      maxZ: 10
    }
  };
}

function formatReport(result) {
  const header = [
    result.ok ? 'PASS: no forbidden collision found.' : `FAIL: ${result.failureCount} forbidden event(s) found.`,
    `Blocks: ${result.blocks}`,
    `Segments: ${result.segments}`,
    `Cuts accepted: ${result.cutCount}`,
    `Warnings: ${result.warningCount}`,
    `Stock: ${result.stockSummary.nx} x ${result.stockSummary.ny} dexels @ ${result.stockSummary.cell}, height ${result.stockSummary.minHeight} .. ${result.stockSummary.maxHeight}`,
    ''
  ];

  const eventLines = result.events.map(event => {
    const line = event.lineNumber ? `L${event.lineNumber}` : 'L?';
    const block = event.block ? `N${event.block}` : 'N?';
    const where = event.position ? ` @ X${event.position.x} Y${event.position.y} Z${event.position.z}` : '';
    return `[${event.severity.toUpperCase()}] ${block}/${line} ${event.kind}: ${event.message}${where}\n  ${event.raw}`;
  });

  const limits = [
    '',
    'Modeled:',
    `- ${result.supported.axes}`,
    `- ${result.supported.moves}`,
    `- ${result.supported.stock}`,
    `- ${result.supported.tool}`,
    '',
    'Known limits:',
    ...result.limitations.map(item => `- ${item}`)
  ];

  return [...header, ...(eventLines.length ? eventLines : ['No events emitted.']), ...limits].join('\n');
}

function runVerification() {
  els.status.textContent = 'running';
  els.report.textContent = 'Running verification kernel...';
  const id = nextJobId++;
  try {
    worker.postMessage({ id, payload: buildPayload() });
  } catch (error) {
    els.status.textContent = 'error';
    els.report.textContent = error instanceof Error ? error.message : String(error);
  }
}

worker.onmessage = event => {
  const { ok, result, error } = event.data;
  if (!ok) {
    els.status.textContent = 'error';
    els.report.textContent = error;
    return;
  }

  result.stock.heights = new Float32Array(result.stock.heights);
  els.status.textContent = result.ok ? 'pass' : 'fail';
  els.report.textContent = formatReport(result);
  renderer.render(result.stock, result.events);
};

worker.onerror = error => {
  els.status.textContent = 'worker error';
  els.report.textContent = error.message;
};

els.sampleSafe.addEventListener('click', () => {
  els.gcode.value = SAFE_SAMPLE;
  runVerification();
});

els.sampleCrash.addEventListener('click', () => {
  els.gcode.value = CRASH_SAMPLE;
  runVerification();
});

els.run.addEventListener('click', runVerification);

els.gcode.value = SAFE_SAMPLE;
runVerification();
